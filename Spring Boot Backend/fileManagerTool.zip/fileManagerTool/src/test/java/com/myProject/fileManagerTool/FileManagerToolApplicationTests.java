package com.myProject.fileManagerTool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileManagerToolApplicationTests {

	@Test
	void contextLoads() {
	}

}

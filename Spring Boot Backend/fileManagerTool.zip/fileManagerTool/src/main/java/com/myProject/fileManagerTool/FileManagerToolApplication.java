package com.myProject.fileManagerTool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileManagerToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileManagerToolApplication.class, args);
	}

}
